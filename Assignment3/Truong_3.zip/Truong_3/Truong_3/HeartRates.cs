﻿using System;
using System.Globalization;

namespace Truong_3
{
  class HeartRates
  {
    private int curYear = DateTime.Now.Year;
    private int age;

    public HeartRates(String firstN, String lastN, int birthY)
    {
      firstName = firstN;
      lastName = lastN;
      birthYear = birthY;
      age = curYear - birthY;
    }
    public String firstName
    {
      get;
      set;
    }
    public String lastName
    {
      get;
      set;
    }
    public int birthYear
    {
      get;
      set;
    }
    public int currentYear
    {
      get
      {
        return curYear = DateTime.Now.Year;
      }
    }
    public int ages
    {
      get
      {
        return age;
      }
    }
    public int maxHeartRates
    {
      get
      {
        return 220 - age;
      }
    }
    public int minTargetHeartRates
    {
      get
      {
        return Convert.ToInt32(0.5 * maxHeartRates);
      }
    }
    public int maxTargetHeartRates
    {
      get
      {
        return Convert.ToInt32(0.85 * maxHeartRates);
      }
    }
    public String printOff
    {
      get
      {
        return String.Format("{0,-30}{1,-10}\n{2, -30}{3,-10}\n{4,-30}{5,-10}\n{6,-30}{7,-10}\n{8,-30}{9,3}{10, 18}\n{11,-30}{12,3}{13,18}\n{14,-30}{15,3}{16,18}",
           "  First Name: ", this.firstName, "  Last Name: ", lastName, "  Birth Year: ", birthYear, "  Age: ", ages,
           "  Max Heart Rate: ", maxHeartRates, " beats per minute", "  Min Target Heart Rate: ", minTargetHeartRates,
           " beats per minute", "  Max Target Heart Rate: ", maxTargetHeartRates, " beats per minute");
      }
    }
  }
}
